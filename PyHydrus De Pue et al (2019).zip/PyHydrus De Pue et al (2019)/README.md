# pyHydrus1D
python implementation of Hydrus-1D
